#!/bin/bash

echo "Welcome to "

echo " 
                                                 ██████
                                                      ██
                                                  █████
                                                 ██
 ██████  █████  ██████  ██       ██████  ███████ ██████             ████████ ██████  ██ ██    ██ ██  █████  ██      
██      ██   ██ ██   ██ ██      ██    ██ ██                            ██    ██   ██ ██ ██    ██ ██ ██   ██ ██      
██      ███████ ██████  ██      ██    ██ ███████                       ██    ██████  ██ ██    ██ ██ ███████ ██      
██      ██   ██ ██   ██ ██      ██    ██      ██                       ██    ██   ██ ██  ██  ██  ██ ██   ██ ██      
 ██████ ██   ██ ██   ██ ███████  ██████  ███████                       ██    ██   ██ ██   ████   ██ ██   ██ ███████ 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
"

read -p "Enter the number of players: " numPlayer

if [ "$numPlayer" -eq 1 ]; then
    echo "The game starts for one player! " 
    ./Questions1.sh
elif [ "$numPlayer" -eq 2 ]; then
    echo "The game begins for two players! "
    ./Questions2.sh
else
    echo "Only can play with 1 or 2 players. "
    exit
fi
