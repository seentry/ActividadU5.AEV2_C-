#!/bin/bash

fileScores="scores.txt"

ShowRank(){
    if [ -e "$fileScores" ]; then
        echo " The Score Ranking: "
        awk -F'|' '{print $1, $2}' "$fileScores"

    else 
        echo "Sorry, no scores have been recorded yet."
    fi
}
while true; do
    echo "1. The Ranking"
    echo "2. Exit"

    echo "Choose an option: " 
    read option

    case $option in
        1) ShowRank; exit  ;;
        2) echo "Thank you for playing"; exit  ;;
        *) echo "This option is not valid." ;;
    esac
done