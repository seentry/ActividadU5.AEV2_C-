#!/bin/bash

green='\e[42m'
red='\033[0;31m'
reset='\033[0m'

fileQuestions="Questions.txt"
scoresFile="scores.txt"

numLines=$(wc -l < "$fileQuestions")

counter=0
playerPoints1=0
playerPoints2=0


while [ $counter -lt 10 ]; do

    randomNumber1=$((0 + RANDOM % (numLines / 2)))
    randomNumber2=$((0 + RANDOM % (numLines / 2)))

    question1=$(sed -n "$((randomNumber1 * 2 + 1))p" "$fileQuestions")
    answer1=$(sed -n "$((randomNumber1 * 2 + 2))p" "$fileQuestions")

    question2=$(sed -n "$((randomNumber2 * 2 + 1))p" "$fileQuestions")
    answer2=$(sed -n "$((randomNumber2 * 2 + 2))p" "$fileQuestions")

        echo "=== Turno $((counter + 1)) ==="

    echo "The quest for 1 player is: "
    echo "$question1"
    read answerUser


    lowercaseAnswer1=$(echo "$answer1" | tr '[:upper:]' '[:lower:]')
    userResponseLowercase1=$(echo "$answerUser" | tr '[:upper:]' '[:lower:]')


    if [[ "$lowercaseAnswer1" == "$userResponseLowercase1" ]]; then
        echo -e "$green ¡Correct! $reset"
        ((playerPoints1++))
    else
        echo -e "$red Fail, the correct answer is $answer1 $reset"
    fi

    echo "The quest for 2 player is: "
    echo "$question2"
    read answerUser

    lowercaseAnswer2=$(echo "$answer2" | tr '[:upper:]' '[:lower:]')
    userResponseLowercase2=$(echo "$answerUser" | tr '[:upper:]' '[:lower:]')

    if [[ "$lowercaseAnswer2" == "$userResponseLowercase2" ]]; then
        echo -e "$green ¡Correct! $reset"
        ((playerPoints2++))
    else
        echo -e "$red Fail, the correct answer is $answer2 $reset"
    fi

    ((counter++))
done
currentDateTime=$(date +"%Y-%m-%d %H:%M:%S")

echo "$currentDateTime - Player 1: $playerPoints1 hits, Player2: $playerPoints2 hits" >> "$scoresFile"

if [ $playerPoints1 -gt $playerPoints2 ]; then
    echo -e "$green Player 1 win with: $playerPoints1 points $reset"
elif [ $playerPoints2 -gt $playerPoints1 ]; then
    echo -e "$green Player 1 win with: $playerPoints2 points $reset"
else 
    echo "Tie"
fi

echo "The player 1 have obtain $playerPoints1 points"
echo "The player 2 have obtain $playerPoints2 points"

